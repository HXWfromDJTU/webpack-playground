(globalThis["webpackChunkwebpack_playground"] = globalThis["webpackChunkwebpack_playground"] || []).push([["src_constant_index_js"],{

/***/ "./src/constant/index.js":
/*!*******************************!*\
  !*** ./src/constant/index.js ***!
  \*******************************/
/*! namespace exports */
/*! export APP_NAME [provided] [no usage info] [missing usage info prevents renaming] */
/*! export APP_VERSION [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "APP_VERSION": () => /* binding */ APP_VERSION,
/* harmony export */   "APP_NAME": () => /* binding */ APP_NAME
/* harmony export */ });
var APP_VERSION = '0.0.3';
var APP_NAME = 'WebpackPlayground';

/***/ })

}]);
//# sourceMappingURL=src_constant_index_js_chunk.js.map