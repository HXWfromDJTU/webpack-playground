(self["webpackChunkwebpack_playground"] = self["webpackChunkwebpack_playground"] || []).push([[916],{

/***/ 916:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "combine": function() { return /* binding */ combine; }
/* harmony export */ });
console.log('utils is loaded.....');
function combine(a, b) {
  console.log(a + b);
}

/***/ })

}]);
//# sourceMappingURL=916_chunk.js.map