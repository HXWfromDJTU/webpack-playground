(self["webpackChunkwebpack_playground"] = self["webpackChunkwebpack_playground"] || []).push([[179],{

/***/ 952:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

"use strict";

;// CONCATENATED MODULE: ./static/data.json
var data_namespaceObject = {"test":"123123"};
// EXTERNAL MODULE: delegated ./node_modules/_vue@2.6.12@vue/dist/vue.runtime.esm.js from dll-reference vue_e6adf
var vue_runtime_esmfrom_dll_reference_vue_e6adf = __webpack_require__(979);
// EXTERNAL MODULE: ./node_modules/_jquery@3.5.1@jquery/dist/jquery.js
var jquery = __webpack_require__(21);
var jquery_default = /*#__PURE__*/__webpack_require__.n(jquery);
;// CONCATENATED MODULE: ./src/helper/index.js

function uselessFun(a) {
  console.log("uselessFun".concat(a));
}
function add(a, b, c) {
  console.log(1000000 + a + b + c);
}
console.log((jquery_default()));
// EXTERNAL MODULE: ./src/components/index.vue
var components = __webpack_require__(799);
var components_default = /*#__PURE__*/__webpack_require__.n(components);
;// CONCATENATED MODULE: ./src/index.js


 // 字体样式入口

 // 图片文件打包



 // 样式文件包

 // 测试 treeShaking

 // vue-loader-test 测试


__webpack_require__.e(/* import() */ 558).then(__webpack_require__.t.bind(__webpack_require__, 558, 23)).then(function (AsyncComponent) {
  console.log(AsyncComponent);
});
console.log((components_default())); // 测试 JavaScript 代码转换测试
// import '@babel/polyfill'; // 粗暴地直接引入整个 polyfill 会导致 JavaScript 体积过大

var testEs6 = 123;
var promiseTest = new Promise(function (resolve) {
  setTimeout(function () {
    console.log('promise resolve');
    resolve();
  });
}); // 使用 ES7 动态引入模块，客观效果可以实现 code-spliting

__webpack_require__.e(/* import() */ 318).then(__webpack_require__.bind(__webpack_require__, 318)).then(function (moduleConstant) {
  console.log('APP_VERSION', moduleConstant.APP_VERSION);
}).catch(function (err) {
  console.log('APP_VERSION Loaded Failed');
});

document.getElementById('btn').onclick = function () {
  // webpackPrefetch: true  设置允许webapck 将资源使用 <link rel="prefetch" href="xxxxx" /> 进行加载 
  __webpack_require__.e(/* import() */ 916).then(__webpack_require__.bind(__webpack_require__, 916)).then(function (utils) {
    utils.combine(1, 2);
  });
}; // 测试 treeShaking


console.log(add(1, 2, 4));
console.log(data_namespaceObject, testEs6, promiseTest);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./service-worker.js') // service-worker.js 会由 workbox-webpack-plugin 生成
    .then(function () {
      console.log('sw 注册成功');
    }).catch(function () {
      console.log('sw 注册失败');
    });
  });
}

console.log(vue_runtime_esmfrom_dll_reference_vue_e6adf.default, (jquery_default()));

/***/ }),

/***/ 799:
/***/ (function() {

with(this){return _c("div")}

/***/ }),

/***/ 979:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = (__webpack_require__(266))(105);

/***/ }),

/***/ 266:
/***/ (function(module) {

"use strict";
module.exports = vue_e6adf;

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ 	"use strict";
/******/ 
/******/ 	/* webpack/runtime/startup prefetch */
/******/ 	!function() {
/******/ 		var startup = __webpack_require__.x;
/******/ 		__webpack_require__.x = function() {
/******/ 			var result = startup();
/******/ 			__webpack_require__.E(916);
/******/ 			return result;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ }
,[[952,252,21]]]);
//# sourceMappingURL=main.97dddabd.js.map