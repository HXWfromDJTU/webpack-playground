<template>
    <div class="container">
        asdasdasd
        <span v-if="flag"></span>
    </div>
</template>
<script>
export default {
    data () {
        return {
            flag: false
        }
    }
}
</script>