(self["webpackChunkwebpack_playground"] = self["webpackChunkwebpack_playground"] || []).push([[318],{

/***/ 318:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "APP_VERSION": function() { return /* binding */ APP_VERSION; },
/* harmony export */   "APP_NAME": function() { return /* binding */ APP_NAME; }
/* harmony export */ });
var APP_VERSION = '0.0.3';
var APP_NAME = 'WebpackPlayground';

/***/ })

}]);
//# sourceMappingURL=318_chunk.js.map