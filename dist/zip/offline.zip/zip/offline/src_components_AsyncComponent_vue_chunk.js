(globalThis["webpackChunkwebpack_playground"] = globalThis["webpackChunkwebpack_playground"] || []).push([["src_components_AsyncComponent_vue"],{

/***/ "./src/components/AsyncComponent.vue":
/*!*******************************************!*\
  !*** ./src/components/AsyncComponent.vue ***!
  \*******************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements: top-level-this-exports */
/*! CommonJS bailout: this is used directly at 1:5-9 */
/***/ (function() {

with(this){return _c("div")}

/***/ })

}]);
//# sourceMappingURL=src_components_AsyncComponent_vue_chunk.js.map