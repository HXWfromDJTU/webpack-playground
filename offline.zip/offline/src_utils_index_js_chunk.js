(globalThis["webpackChunkwebpack_playground"] = globalThis["webpackChunkwebpack_playground"] || []).push([["src_utils_index_js"],{

/***/ "./src/utils/index.js":
/*!****************************!*\
  !*** ./src/utils/index.js ***!
  \****************************/
/*! namespace exports */
/*! export combine [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "combine": () => /* binding */ combine
/* harmony export */ });
console.log('utils is loaded.....');
function combine(a, b) {
  console.log(a + b);
}

/***/ })

}]);
//# sourceMappingURL=src_utils_index_js_chunk.js.map